package io.javabrains.junit.junit5basic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Junit5BasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(Junit5BasicApplication.class, args);
	}

}
