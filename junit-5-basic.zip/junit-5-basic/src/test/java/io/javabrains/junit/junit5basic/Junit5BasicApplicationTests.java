package io.javabrains.junit.junit5basic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Junit5BasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
